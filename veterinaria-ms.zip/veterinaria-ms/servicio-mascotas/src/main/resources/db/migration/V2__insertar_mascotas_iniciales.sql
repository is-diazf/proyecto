INSERT INTO mascotas (nombre, raza, fecha_nacimiento_mascota) VALUES
('Max', 'Pastor Aleman', '2022-11-29'),
('Floki', 'Gato Montes', '2026-01-12'),
('Oscar', 'Shiwuawa', '2021-04-01'),
('Rovin', 'Salchicha', '2025-08-17');