CREATE TABLE recetas (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_historial BIGINT NOT NULL,
    id_mascota BIGINT NOT NULL,
    medicamento VARCHAR(50) NOT NULL,
    dosis VARCHAR(100),
    duracion_dias INT,
    indicaciones TEXT,
    fecha_emision DATE NOT NULL,
    fecha_creacion TIMESTAMP NOT NULL
);