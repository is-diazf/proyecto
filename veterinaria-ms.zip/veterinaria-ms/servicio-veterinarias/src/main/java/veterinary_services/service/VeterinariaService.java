package veterinary_services.service;

import veterinary_services.dto.VeterinariaRequestDTO;
import veterinary_services.dto.VeterinariaResponseDTO;
import veterinary_services.model.Veterinaria;
import veterinary_services.repository.VeterinariaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class VeterinariaService {

    private final VeterinariaRepository veterinariaRepository;

    public List<VeterinariaResponseDTO> listarTodas() {
        return veterinariaRepository.findAll().stream()
            .map(this::mapearADto)
            .collect(Collectors.toList());
    }

    public VeterinariaResponseDTO obtenerVeterinaria(Long id) {
        Veterinaria veterinaria = veterinariaRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Veterinaria no encontrada con id: " + id));
        return mapearADto(veterinaria);
    }

    public VeterinariaResponseDTO guardarVeterinaria(VeterinariaRequestDTO veterinariaRequestDTO) {
        Veterinaria veterinaria = new Veterinaria();
        veterinaria.setNombre(veterinariaRequestDTO.getNombre());
        veterinaria.setDireccion(veterinariaRequestDTO.getDireccion());
        veterinaria.setTelefono(veterinariaRequestDTO.getTelefono());
        
        Veterinaria veterinariaGuardada = veterinariaRepository.save(veterinaria);
        return mapearADto(veterinariaGuardada);
    }

    public VeterinariaResponseDTO actualizarVeterinaria(Long id, VeterinariaRequestDTO detallesVeterinaria) {
        Veterinaria veterinariaExistente = veterinariaRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Veterinaria no encontrada con id: " + id));
        
        veterinariaExistente.setNombre(detallesVeterinaria.getNombre());
        veterinariaExistente.setDireccion(detallesVeterinaria.getDireccion());
        veterinariaExistente.setTelefono(detallesVeterinaria.getTelefono());
        
        Veterinaria veterinariaActualizada = veterinariaRepository.save(veterinariaExistente);
        return mapearADto(veterinariaActualizada);
    }

    public void eliminarVeterinaria(Long id) {
        Veterinaria veterinaria = veterinariaRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Veterinaria no encontrada con id: " + id));
        veterinariaRepository.delete(veterinaria);
    }

    private VeterinariaResponseDTO mapearADto(Veterinaria veterinaria) {
        VeterinariaResponseDTO dto = new VeterinariaResponseDTO();
        dto.setId(veterinaria.getId());
        dto.setNombre(veterinaria.getNombre());
        dto.setDireccion(veterinaria.getDireccion());
        dto.setTelefono(veterinaria.getTelefono());
        return dto;
    }
}