CREATE table if not exists veterinarias(
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    direccion VARCHAR(200) NOT NULL UNIQUE,
    telefono VARCHAR(8) NOT NULL UNIQUE  
);