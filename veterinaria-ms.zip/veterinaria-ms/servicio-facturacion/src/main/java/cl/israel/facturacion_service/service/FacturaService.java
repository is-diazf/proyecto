package cl.israel.facturacion_service.service;

import cl.israel.facturacion_service.model.Factura;
import cl.israel.facturacion_service.repository.FacturaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class FacturaService {

    private final FacturaRepository facturaRepository;

    public Factura crearFactura(Factura factura) {
        factura.setFechaEmision(LocalDateTime.now());
        factura.setEstado("PENDIENTE");  // ← Sin "estado:"
        return facturaRepository.save(factura);
    }

    public List<Factura> listarFacturas() {
        return facturaRepository.findAll();  // ← findAll, no findA11
    }

    public Factura obtenerPorId(Long id) {
        if (id == null) {
            throw new IllegalArgumentException("El ID no puede ser nulo");
        }
        return facturaRepository.findById(id).orElse(null);
    }

    public void eliminarFactura(Long id) {
        if (id == null) {
            throw new IllegalArgumentException("El ID no puede ser nulo");
        }
        facturaRepository.deleteById(id);
    }
}