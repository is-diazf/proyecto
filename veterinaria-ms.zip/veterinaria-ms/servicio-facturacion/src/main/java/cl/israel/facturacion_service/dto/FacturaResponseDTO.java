package cl.israel.facturacion_service.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class FacturaResponseDTO {
    private Long id;
    private Long idCita;
    private Double montoTotal;
    private LocalDateTime fechaEmision;
    private String estado;
    private String metodoPago;
}