package cl.israel.citas.service;

import cl.israel.citas.client.VeterinarioClient;
import cl.israel.citas.dto.CitaResponseDTO;
import cl.israel.citas.dto.VeterinarioDTO;
import cl.israel.citas.model.Citas;
import cl.israel.citas.repository.CitaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CitaService {

    private final CitaRepository citaRepository;
    private final VeterinarioClient veterinarioClient;

    public Citas crearCita(Citas cita) {
        // Validar que el veterinario exista
        VeterinarioDTO veterinario = veterinarioClient.obtenerVeterinario(cita.getIdVeterinario());
        if (veterinario == null) {
            throw new RuntimeException("Veterinario no encontrado");
        }
        System.out.println("Veterinario encontrado: " + veterinario.getNombre());
        return citaRepository.save(cita);
    }

    public List<CitaResponseDTO> listarTodas() {
        return citaRepository.findAll().stream()
            .map(this::convertirADTO)
            .collect(Collectors.toList());
    }

    private CitaResponseDTO convertirADTO(Citas cita) {
        CitaResponseDTO dto = new CitaResponseDTO();
        dto.setId(cita.getId());
        dto.setIdVeterinario(cita.getIdVeterinario());
        dto.setNombreMascota(cita.getNombreMascota());
        dto.setRazaMascota(cita.getRazaMascota());
        dto.setNombreDueño(cita.getNombreDueño());
        dto.setTelefonoDueño(cita.getTelefonoDueño());
        dto.setFechaCita(cita.getFechaCita());
        dto.setHoraCita(cita.getHoraCita());
        dto.setMotivoCita(cita.getMotivoCita());
        return dto;
    }
}