create table citas (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    idveterinario BIGINT NOT NULL,
    nombre_mascota VARCHAR(100) NOT NULL,
    raza_mascota VARCHAR(50),
    nombre_dueño VARCHAR(100) NOT NULL,
    telefono_dueño VARCHAR(15),
    fecha_cita DATE NOT NULL,
    hora_cita TIME NOT NULL,
    motivo_cita VARCHAR(200)
);